// Add the key, forceTLS, cluster options here.
const PusherConfig = {
  key: 'e79eb4a42fb518353ee1',
  cluster: 'ap2',
  forceTLS: true
};
