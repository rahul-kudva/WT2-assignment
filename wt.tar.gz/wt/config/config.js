// Add the appId, key, secret, cluster here.
const PusherServerConfig = {
  appId: '901346',
  key: 'e79eb4a42fb518353ee1',
  secret: 'cc79ff1898bd8aef40e5',
  cluster: 'ap2',
  encrypted: true
};

// Export this module.
module.exports = PusherServerConfig;
